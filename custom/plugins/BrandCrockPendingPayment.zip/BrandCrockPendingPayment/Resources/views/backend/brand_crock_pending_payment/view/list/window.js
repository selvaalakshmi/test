
Ext.define('Shopware.apps.BrandCrockPendingPayment.view.list.Window', {
    extend: 'Shopware.window.Listing',
    alias: 'widget.product-list-window',
    height: 650,
    width: 1280,
    title : 'Pending payment details',

    configure: function() {
        return {
            listingGrid: 'Shopware.apps.BrandCrockPendingPayment.view.list.Product',
            listingStore: 'Shopware.apps.BrandCrockPendingPayment.store.Product',

            extensions: [
                { xtype: 'product-listing-filter-panel' }
            ]
        };
    }
});

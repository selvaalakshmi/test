Ext.define('Shopware.apps.BrandCrockPendingPayment.view.list.Product', {
    extend: 'Shopware.grid.Panel',
    alias:  'widget.product-listing-grid',
    region: 'center',
    configure: function() {
        return {
            detailWindow: 'Shopware.apps.BrandCrockPendingPayment.view.detail.Window',
            addButton: false,
            deleteButton: false,
            editColumn: false,
            deleteColumn: false,
        };
    },

    createToolbarItems: function () {
        var me = this, items = [];

        items.push(me.createCsvButton());

        return items;
    },
    createCsvButton: function () {
        var me = this;

        me.addButton = Ext.create('Ext.button.Button', {
            text: 'Download csv',
            iconCls: 'sprite-drive-download',
              listeners: {
                click: function () {
                    var url = '{url controller=BrandCrockPendingPayment action=list}';
                    url += '?format=csv';
                    var form = Ext.create('Ext.form.Panel', {
                        standardSubmit: true,
                        target: 'iframe'
                    });

                    form.submit({
                        method: 'POST',
                        url: url
                    });
                    },
                }
        });

        me.fireEvent(me.eventAlias + '-add-button-created', me, me.addButton);

        return me.addButton;
    },
});

<?php

use BrandCrockPendingPayment\Models\Product;
use Shopware\Components\CSRFWhitelistAware;
class Shopware_Controllers_Backend_BrandCrockPendingPayment extends Shopware_Controllers_Backend_Application  implements CSRFWhitelistAware
{
    protected $model = Product::class;
    protected $alias = 'product';

    public function getWhitelistedCSRFActions()
    {
        return [
            'list',
        ];
    }

    public function listAction()
    {
        $format = $this->Request()->getParam('format');
        $session = Shopware()->BackendSession();
        $filter = $this->Request()->getParam('filter', []);
        $start = $this->Request()->getParam('start');
        $limit =$this->Request()->getParam('limit');
        $sort = $this->Request()->getParam('sort', []);
        if(!$filter) {
            $repository = Shopware()->Models()->getRepository(\Shopware\Models\Order\Order::class);
            $builder = $repository->getOrdersQueryBuilder($filters, $orderBy);
            if ($limit !== null) {
                $builder->setFirstResult($start)
                ->setMaxResults($limit);
            }
            $paginator = $this->getQueryPaginator($builder);
            $data = $paginator->getIterator()->getArrayCopy();
            $count = $paginator->count();
            foreach ($data as $k => $values) {
                $now = $values['orderTime'];
                $datas[$k]['invoiceAmount'] = $values['invoiceAmount'];
                $datas[$k]['cleareddate'] = $values['cleareddate'];
                $datas[$k]['invoiceAmountNet'] = $values['invoiceAmountNet'];
                $datas[$k]['number'] = $values['number'];
                $datas[$k]['orderTime'] = $now->format('Y-m-d');
                $datas[$k]['customerFirstName'] = $values['billing']['firstName'];
                $datas[$k]['customerLastName'] = $values['billing']['lastName'];
                $datas[$k]['company'] = $values['billing']['company'];
                $datas[$k]['payment'] = $values['payment']['name'];
                $orderID = $data[$k]['id'];
                $bcDate = Shopware()->Db()->fetchRow("SELECT bc_due_date, bc_over_due FROM s_order_attributes where orderID = '$orderID'");
                $bcDueDate = $bcDate['bc_due_date'];
                $bcOverDue = $values['clearedDate'];
                $dateTimestamp1 = strtotime($bcDueDate);
                $dateTimestamp2 = strtotime($bcOverDue);
                if(empty($bcOverDue) || $bcOverDue == null){
                    $datas[$k]['overdue'] = 'Pending';
                } else  if ($dateTimestamp1 > $dateTimestamp2) {
                    $datas[$k]['overdue'] = 'No';
                }else
                {
                    $datas[$k]['overdue'] = 'Yes';
                }
                $datas[$k]['invoiceNumber'] =  '';
                $datas[$k]['documentDate'] =  '';
                if( $values['documents'] ) {
                    foreach ($values['documents'] as $kee => $value) {
                        if ($value['type']['key'] =='invoice') {
                            $datas[$k]['invoiceNumber'] =  $value['documentId'];
                            $nows = $value['date'];
                            $datas[$k]['documentDate'] =  $nows->format('Y-m-d');
                        }
                    }
                }
            }
        } else {
        $where_append = "";

         if(!empty($filter))
         {
            foreach ($filter as $k => $v )
            {
             if($v['property'] == 'number')
             {
                $v['property'] = 'ord.ordernumber';
             }
             if($v['property'] == 'documentDate')
             {
                $v['property'] = '%doc.date%';
             }
              if($v['property'] == 'invoiceAmount')
             {
                $v['property'] = 'ord.invoice_amount';
             }
              if($v['property'] == 'invoiceAmountNet')
             {
                $v['property'] = 'ord.invoice_amount_net';
             }
              if($v['property'] == 'orderTime')
             {
                $v['property'] = '%ord.ordertime%';
             }
              if($v['property'] == 'customerComment')
             {
                $v['property'] = '%ord.customercomment%';
             }
              if($v['property'] == 'customerFirstName')
             {
                $v['property'] = '%billing.firstname%';
             }
              if($v['property'] == 'customerLastName')

             {

                $v['property'] = '%billing.lastname%';

             }

             if($v['property'] == 'invoiceNumber')

             {

                $v['property'] = 'doc.docID';

             }

             if($v['property'] == 'payment')

             {

                $v['property'] = 'ord.paymentID';

             }

             if($v['property'] == 'overdue')

             {

                $v['property'] = '%bc.overdue_date%';

             }

             if($k == 0) { $condition = ""; } else { $condition = "OR"; }

             if (is_array($v['value']))

             {

             $val = implode("," , $v['value']);

             $value_data = "(".$val.")";

             $equal_in = 'in';

             }

             else

             {

             $value_data = "'".$v['value']."'";

             $equal_in = '=';

             }



             $where_append.= " ".$condition." ".$v['property'] ." ".$equal_in .  $value_data;



            }

           }

            $sResultData = '';

            $sqlQuery = "SELECT  DISTINCT(ord.id),company,firstname,lastname,name,docID,date,ord.ordernumber,invoice_amount,invoice_amount_net,ordertime,customercomment,paymentID,overdue_date

            FROM s_order as ord

            LEFT JOIN s_order_billingaddress as billing ON billing.userID = ord.userID

            LEFT JOIN s_core_paymentmeans as pay ON pay.id = ord.paymentID

            LEFT JOIN s_order_documents as doc ON doc.orderID = ord.id

            LEFT JOIN bc_order_filter as bc ON bc.ordernumber = ord.ordernumber

            where $where_append";

            $sResultData = Shopware()->Db()->fetchAll($sqlQuery);



            foreach($sResultData as $key => $values ){



                $datas[$key]['documentDate'] = $values['date'];

                $datas[$key]['invoiceAmount'] = $values['invoice_amount'];

                $datas[$key]['invoiceAmountNet'] = $values['invoice_amount_net'];

                $datas[$key]['orderTime'] = $values['ordertime'];

                $datas[$key]['customerComment'] = $values['customercomment'];

                $datas[$key]['number'] = $values['ordernumber'];

                $datas[$key]['customerFirstName'] = $values['firstname'];

                $datas[$key]['customerLastName'] = $values['lastname'];





                if($datas[$key]['payment'] = $values['paymentID']){

                    $idP = $values['paymentID'];

                    $pay_name = "select name from s_core_paymentmeans where id ='$idP'";

                    $pay_name_res = Shopware()->Db()->fetchAll($pay_name);

                }

                $datas[$key]['payment'] = $pay_name_res[0]['name'];

                $datas[$key]['company'] = $values['company'];

                $datas[$key]['invoiceNumber'] = $values['docID'];

                $datas[$key]['overdue'] = $values['overdue_date'];

            }
            $count = count($datas);
            $session->bcLoadedData = $datas;
        }

        if($format) {

            //~ var_dump($session->bcLoadedData);
            if($session->bcLoadedData) {
                $datass = $session->bcLoadedData;
            }


            $this->exportCSV($datass);
        }
        //~ echo '<pre>'; print_r($datas); exit;
        $session->bcLoadedData = $datas;
        $this->View()->assign(['success'=> true,'data' => $datas , 'total' => $count]);

    }
    protected function exportCSV($data)
    {
        $this->Front()->Plugins()->Json()->setRenderer(false);
        $this->Response()->setHeader('Content-Type', 'text/csv; charset=utf-8');
        $this->Response()->setHeader('Content-Disposition', 'attachment;filename=' . 'csvfile.csv');

        echo "\xEF\xBB\xBF";
        $fp = fopen('php://output', 'w');
        fputcsv($fp, array_keys($data[0]), ';');
        foreach ($data as $k =>  $line) {
                fputcsv($fp, $line,';');
        }
        foreach ($data as $key => $value) {
            $invoiceAmountNet[] =  $value['invoiceAmountNet'];
            $invoiceAmount[] =  $value['invoiceAmount'];
        }
        $invoiceAmount = array_sum($invoiceAmount);
        $invoiceAmountNet = array_sum($invoiceAmountNet);
        $sum = [
        'TotalAmount' => $invoiceAmount,
        'TotalNet' => $invoiceAmountNet
        ];
        fputcsv($fp, array_keys($sum), ';');
        fputcsv($fp, array_values($sum), ';');
        foreach ($sum  as $k => $val) {
            fputcsv($fp, $val,';');
        }
        fclose($fp);
    }

}

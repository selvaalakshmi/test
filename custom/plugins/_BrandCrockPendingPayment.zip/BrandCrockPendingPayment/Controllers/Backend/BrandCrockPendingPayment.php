<?php

use BrandCrockPendingPayment\Models\Product;
use Shopware\Components\CSRFWhitelistAware;
class Shopware_Controllers_Backend_BrandCrockPendingPayment extends Shopware_Controllers_Backend_Application  implements CSRFWhitelistAware
{
    protected $model = Product::class;
    protected $alias = 'product';

    public function getWhitelistedCSRFActions()
    {
        return [
            'csvdownload',
        ];
    }
  
    public function listAction()
    {
        $filter = $this->Request()->getParam('filter', []);


        if(!$filter) {
            $numberRepository = Shopware()->Models()->getRepository(\Shopware\Models\Order\Order::class);
            $query = $numberRepository->getOrdersQuery();
            $data = $query->getArrayResult();
                 foreach ($data as $k => $values) {
                 $now = $values['orderTime'];
                 $datas[$k]['invoiceAmount'] = $values['invoiceAmount'];
                 $datas[$k]['invoiceAmountNet'] = $values['invoiceAmountNet'];
                 $datas[$k]['number'] = $values['number'];
                 $datas[$k]['orderTime'] = $now->format('Y-m-d');
                 $datas[$k]['customerFirstName'] = $values['billing']['firstName'];
                 $datas[$k]['customerLastName'] = $values['billing']['lastName'];
                 $datas[$k]['company'] = $values['billing']['company'];
                 $datas[$k]['payment'] = $values['payment']['name'];
                 $datas[$k]['overdue'] = 'Yes';
                 if( $values['documents'] ) {
                     foreach ($values['documents'] as $kee => $value) {
                         if ($value['type']['key'] =='invoice') {
                            $datas[$k]['invoiceNumber'] =  $value['documentId'];
                            $nows = $value['date'];
                            $datas[$k]['documentDate'] =  $nows->format('Y-m-d');
                         }
                     }
                 }
            }
            /*foreach ($data as $k => $values) {
                 $now = $values['orderTime'];
                 $data[$k]['orderTime'] = $now->format('Y-m-d');
                 $data[$k]['customerFirstName'] = $values['billing']['firstName'];
                 $data[$k]['customerLastName'] = $values['billing']['lastName'];
                 $data[$k]['company'] = $values['billing']['company'];
                 $data[$k]['payment'] = $values['payment']['name'];
                 $data[$k]['overdue'] = 'Yes';
                 if( $values['documents'] ) {
                     foreach ($values['documents'] as $kee => $value) {
                         if ($value['type']['key'] =='invoice') {
                            $data[$k]['invoiceNumber'] =  $value['documentId'];
                            $nows = $value['date'];
                            $data[$k]['documentDate'] =  $nows->format('Y-m-d');
                         }
                     }
                 }
            }*/
        } else {

        }
        //~ Shopware()->Session()->PreviouesData = $datas;
        $this->View()->assign(['success'=> true,'data' => $datas ,count($datas)]);
    }
    function getdatas()
    {
        $filter = $this->Request()->getParam('filter', []);


        if(!$filter) {
            $numberRepository = Shopware()->Models()->getRepository(\Shopware\Models\Order\Order::class);
            $query = $numberRepository->getOrdersQuery();
            $data = $query->getArrayResult();
            foreach ($data as $k => $values) {
                 $now = $values['orderTime'];
                 $datas[$k]['invoiceAmount'] = $values['invoiceAmount'];
                 $datas[$k]['invoiceAmountNet'] = $values['invoiceAmountNet'];
                 $datas[$k]['number'] = $values['number'];
                 $datas[$k]['orderTime'] = $now->format('Y-m-d');
                 $datas[$k]['customerFirstName'] = $values['billing']['firstName'];
                 $datas[$k]['customerLastName'] = $values['billing']['lastName'];
                 $datas[$k]['company'] = $values['billing']['company'];
                 $datas[$k]['payment'] = $values['payment']['name'];
                 $datas[$k]['overdue'] = 'Yes';
                 if( $values['documents'] ) {
                     foreach ($values['documents'] as $kee => $value) {
                         if ($value['type']['key'] =='invoice') {
                            $datas[$k]['invoiceNumber'] =  $value['documentId'];
                            $nows = $value['date'];
                            $datas[$k]['documentDate'] =  $nows->format('Y-m-d');
                         }
                     }
                 }
            }
            return $datas;
        } else {

        }
    }
    public function csvdownloadAction()
    {
        $data = $this->getdatas();

        $this->exportCSV($data);
    }
    protected function exportCSV($data)
    {
        $this->Front()->Plugins()->Json()->setRenderer(false);
        $this->Response()->setHeader('Content-Type', 'text/csv; charset=utf-8');
        $this->Response()->setHeader('Content-Disposition', 'attachment;filename=' . 'csvfile.csv');

        echo "\xEF\xBB\xBF";
        $fp = fopen('php://output', 'w');
         fputcsv($fp, array_keys($data[0]), ';');
        foreach ($data as $k =>  $line) {
                fputcsv($fp, $line,';');
                	//~ $invoiceAmountNet[] =  $value['invoiceAmountNet'];
					//~ $invoiceAmount[] =  $value['invoiceAmount'];
        }
//~ echo '<pre>';
foreach ($data as $key => $value) {
	$invoiceAmountNet[] =  $value['invoiceAmountNet'];
	$invoiceAmount[] =  $value['invoiceAmount'];
}
$invoiceAmount = array_sum($invoiceAmount);
$invoiceAmountNet = array_sum($invoiceAmountNet);
$sum = [
'TotalAmount' => $invoiceAmount,
'TotalNet' => $invoiceAmountNet
];
fputcsv($fp, array_keys($sum), ';');
fputcsv($fp, array_values($sum), ';');
foreach ($sum  as $k => $val) {
	fputcsv($fp, $val,';');
}
      fclose($fp);
         //~ echo __line__; exit;
    }
   
}



Ext.define('Shopware.apps.BrandCrockPendingPayment.view.list.extensions.Filter', {
    extend: 'Shopware.listing.FilterPanel',
    alias:  'widget.product-listing-filter-panel',
    width: 270,

    configure: function() {
		var paymentStatusStore = Ext.create('Shopware.apps.Base.store.OrderStatus'),
            orderStatusStore = Ext.create('Shopware.apps.Base.store.Payment');
        return {
            controller: 'BrandCrockPendingPayment',
            model: 'Shopware.apps.BrandCrockPendingPayment.model.Product',
            fields: {
                number: 'Order number',
                documentDate: 'documentDate',
                invoiceAmount: 'invoiceAmount',
                invoiceAmountNet: 'invoiceAmountNet',
                orderTime: 'orderTime',
                customerComment: 'customerComment',
                customerFirstName: 'customerFirstName',
                customerLastName: 'customerLastName',
                company: 'company',
                invoiceNumber: 'invoiceNumber',
                payment: {
                    xtype: 'combobox',
                    fieldLabel: 'payment Types',
                    displayField: 'description',
                    valueField: 'id',
                    store: orderStatusStore,
                    multiSelect: true,
                },
                overdue: {
                    xtype: 'combobox',
                    fieldLabel: 'overdue',
                    displayField: 'description',
                    valueField: 'id',
                    store: [[1,'No'],[2,'yes']]
                },
            }
        };
    },
});





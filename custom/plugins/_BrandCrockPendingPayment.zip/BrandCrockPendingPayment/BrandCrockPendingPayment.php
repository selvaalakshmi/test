<?php

namespace BrandCrockPendingPayment;
use Shopware\Components\Plugin;
class BrandCrockPendingPayment extends Plugin
{

}
